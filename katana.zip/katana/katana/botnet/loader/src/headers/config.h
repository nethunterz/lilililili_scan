#pragma once

#define HTTP_SERVER "194.147.142.248"
#define HTTP_PORT 80

#define TFTP_SERVER "194.147.142.248"
